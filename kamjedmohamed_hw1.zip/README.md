Run wrapper.py
The code will return actual corner and reprojected corners for both an initila A matrix and an optimized A matrix